<?php                            //connection & credentials
$servername = "localhost";      //mysql is on the same host as apache
$dbname = "employees";          //which db you're going to use
$username = "anton7738";
$password = "ilovemath2361Apache";
?>
